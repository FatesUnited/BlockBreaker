2/1/2014
Breakout Clone v1.0
Tom "Tribeman" Phillips
[Fates United]

Class to begin the game
This was made for my UIC CS 426 - Video Game Design course.

This game works with an XBOX 360 controller.

Inputs:
- A and D, or the left and right arrow keys move your paddle left and right.
- Start/Enter/Return begin the game
- Spacebar launches the ball, Y on the XBOX 360 controller.
- ESC button kills the ball. Sometimes the ball gets stuck moving only horizontally.

Secrets
-------
At the Game Over screen you will be told to "Try 'BULBASAUR'".
If you cannot figure it out, this is a XBOX 360 controller ONLY cheat.
The button combination is:
B, D-pad UP, LB (Left bumper), A, Select, A, D-pad UP, D-pad RIGHT. Then press Start.


